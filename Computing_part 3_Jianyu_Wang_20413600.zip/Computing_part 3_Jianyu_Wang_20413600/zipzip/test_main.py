from model import FindHeightest
from numpy import arange
import numpy

eplus_run_path = './energyplus9.5/energyplus'
idf_path = './1ZoneUncontrolled_win_1.idf'
output_dir = './result1'
epjson_path = "./1ZoneUncontrolled_win_1.epJSON"

list_shgc=[(i/100) for i in range(25,76,10)]
list_u=[(i/10) for i in range(10,26,1)]

res_shgc = 0
res_u=0
max_val = -999999999
for parameter_val in list_shgc:
    for parameter_val_u in list_u:
        fh = FindHeightest(idf_path=idf_path,output_dir=output_dir,epjson_path=epjson_path , eplus_run_path=eplus_run_path,parameter_val=(parameter_val,parameter_val_u))
    
        fh.run()
        if fh.mean_temperature>max_val:
            max_val = fh.mean_temperature
            res_shgc = parameter_val
            res_u = parameter_val_u
print("Process over!")
print("shgc heightest temperature: "+str(res_shgc))
print("u_factor heightest temperature: "+str(res_u))