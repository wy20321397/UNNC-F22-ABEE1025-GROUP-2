import json
import pandas as pd

from StaticEplusEngine import run_eplus_model, convert_json_idf


class FindHeightest(object):
    def __init__(self, eplus_run_path,idf_path, output_dir,epjson_path,  parameter_val):
        
        self.parameter_val=parameter_val
        
        self.epjson_path=epjson_path
        
        self.eplus_run_path = eplus_run_path
        
        self.idf_path = idf_path
        
        self.output_dir = output_dir
        
        convert_json_idf(self.eplus_run_path, self.idf_path)
        

    def convert(self,val1,val2):
        with open(self.epjson_path) as epJSON:
            epjson_dict = json.load(epJSON)
            
        
        epjson_dict['WindowMaterial:SimpleGlazingSystem']['SimpleWindow:DOUBLE PANE WINDOW']['solar_heat_gain_coefficient'] = val1
        
        epjson_dict['WindowMaterial:SimpleGlazingSystem']['SimpleWindow:DOUBLE PANE WINDOW'][
            'u_factor'] = val2
        
        with open(self.epjson_path, 'w') as epjson:
            json.dump(epjson_dict, epjson)

        
        run_eplus_model(self.eplus_run_path, self.epjson_path, self.output_dir)

    def run(self):
        
        val1,val2=self.parameter_val
        
        self.convert(val1,val2)
        df = pd.read_csv(self.output_dir + "/eplusout.csv")
        temp=df['ZN001:WALL001:WIN001:Surface Inside Face Temperature [C](TimeStep)']
        self.mean_temperature = temp.mean()
        
    
    